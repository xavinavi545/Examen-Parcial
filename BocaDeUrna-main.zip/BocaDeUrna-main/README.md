# BocaDeUrna
Sistema para registro de votos - BOCA DE URNA
